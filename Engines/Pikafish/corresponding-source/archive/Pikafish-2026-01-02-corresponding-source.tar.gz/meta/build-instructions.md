# NativeXiangqi Pikafish helper rebuild instructions

Locked engine: Pikafish-2026-01-02, commit ce0679e00ee196f7ba17f6ec18941b9a5036f8cf.

1. Verify the source tree digest against checksums.sha256.
2. Apply the project patch (patches/0001-pin-release-version.patch) to the
   tree with `patch -p1` from the tree root.
3. Stage the hash-verified NNUE (53212941 bytes, SHA-256
   c4026370d7516d9b0f668447f9ca1931241538bdc689cde6fec6a991ac4d5f77) at `src/pikafish.nnue` so the upstream net target skips
   its download. Never run the build with network access.
4. Build offline with the locked command:

~~~bash
cd src
make build ARCH=apple-silicon COMP=clang GIT_SHA=ce0679e0 GIT_DATE=20260103 -j$(sysctl -n hw.ncpu)
~~~

The GIT_SHA/GIT_DATE overrides pin the engine's own locked commit because the
upstream Makefile would otherwise probe the enclosing repository. The output
executable at `src/pikafish` must equal the recorded helper SHA-256.
